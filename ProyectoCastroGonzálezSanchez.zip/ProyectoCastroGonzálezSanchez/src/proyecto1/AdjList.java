package proyecto1;

import javax.swing.JOptionPane;

/**
 *
 * @author yilme
 */
// Adjacency Matrix representation in Java

public final class AdjList {
    
  private Cell pFirst;
  private Cell pLast;
  private int size;
  private int numLenght;
  private int numWidth;
  
  public AdjList(){
      this.pFirst = null;
      this.pLast = null;
      this.size = 0;
  }
  
  public AdjList(int numLenght, int numWidth) {
    this.numLenght = numLenght;
    this.numWidth = numWidth;
    this.pFirst = null;
    this.pLast = null;
    this.size = numLenght*numWidth;
    this.appendCells();
    this.setCellNum();
//    this.setCellNeighboors();
    }
  
    public boolean IsEmpty() {
        return this.pFirst == null;
    }
    
    public void setCellNeighboors(){
        Cell aux = pFirst;
        for (int i = 0; i < this.size; i++) {
//            agarra todas las celdas en un for
        }
    }
    
    
//    asgina los vecinos de cada celda de la lista
    public void findCellNeihgboors(int numLenght, int numWidth){
        Cell temp = pFirst;
        
        for (int i = 0; i < numWidth-1; i++) {
            Cell next = temp.getpNext();
            temp.setRightCell(next);
            next.setLeftCell(temp);
            temp = next;
        }
        
        Cell aux = pFirst;
        for (int i = 0; i < numLenght-1; i++) {
            temp = temp.getpNext();
            aux.setBottomCell(temp);
            temp.setTopCell(aux);
            
            for (int j = 0; j < numWidth-1; j++) {
                Cell next = temp.getpNext();
                temp.setRightCell(next);
                next.setLeftCell(temp);
                
                aux = aux.getpNext();
                aux.setBottomCell(next);
                next.setTopCell(aux);
                
                temp = next;
            }   
        }
    }
    
    public boolean contains(int num){
        Cell aux = new Cell();
        int auxnum = aux.getNum();
        for (int i = 0; i < this.size; i++) {
            if (num == auxnum){
                return true;
            } else {
                num++;
            }
        }
        return false;
    }
    
    public Cell findCell(int num){
        Cell aux = new Cell();
        aux = this.pFirst;
        for (int i = 0; i < num-1 ; i++) {
            aux = aux.getpNext();
        }
        return aux;
    }
    
//    añade celdas a la lista
    public void appendCells() {
        for (int i = 0; i < this.size; i++) {  
            Cell cell = new Cell();
            if (IsEmpty()) {
                this.pFirst = cell;
                this.pLast = cell;
            } else {
                Cell aux = pLast;
                aux.setpNext(cell);
                pLast = cell;
            }
        }       
    }
    
//    asigna un numero a cada celda según su posición
    public void setCellNum() {
        Cell aux = pFirst;
        for (int i = 0; i < this.size; i++) {
            aux.setNum(i+1);
            aux = aux.getpNext();
        }
    }
    
    public void append(Cell cell) {
        if (IsEmpty()) {
            this.pFirst = cell;
            this.pLast = cell;
        } else {
            Cell aux = pLast;
            aux.setpNext(cell);
            pLast = cell;
        }
        size += 1;
    }
    
    public void Delete(int num){
        if (num > size){
            JOptionPane.showMessageDialog(null, "Error, el número excede el tamaño de la lista.");
        } else if (num == 0){
            pFirst = pFirst.getpNext();
            size -= 1;
        } else if (num == size){
            Cell aux = pFirst;
            for (int i = 0; i < size - 2 ; i++) {
            aux = aux.getpNext();
            }
            aux.setpNext(null);
            size -= 1;
        } else if (!IsEmpty()){
            Cell aux = pFirst;
            for (int i = 0; i < num - 1 ; i++) {
                aux = aux.getpNext();
            }
            Cell next = aux.getpNext().getpNext();
            aux.setpNext(next);
            size -= 1;
        }
    }
    
    public void Print() {
        if (!IsEmpty()) {
            Cell aux = pFirst;
            for (int i = 0; i < this.size; i++) {
                System.out.println(aux.getNum());
                aux = aux.getpNext();
            }
        } else {
            System.out.println("La lista está vacía.");
        }
    }
    
    
    
//    Getters & setters
    public Cell getpFirst() {
        return pFirst;
    }

    public void setpFirst(Cell pFirst) {
        this.pFirst = pFirst;
    }

    public Cell getpLast() {
        return pLast;
    }

    public void setpLast(Cell pLast) {
        this.pLast = pLast;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getNumLenght() {
        return numLenght;
    }

    public void setNumLenght(int numLenght) {
        this.numLenght = numLenght;
    }

    public int getNumWidth() {
        return numWidth;
    }

    public void setNumWidth(int numWidth) {
        this.numWidth = numWidth;
    }


  }