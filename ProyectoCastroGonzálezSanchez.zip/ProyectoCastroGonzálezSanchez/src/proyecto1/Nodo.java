/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto1;


public class Nodo {
    private Object data;
    private Nodo pNext;

    public Nodo(Object data){
        this.data = data;
        this.pNext = null;       
    }
    
    public Nodo(Object data, Nodo node){
        this.data = data;
        this.pNext = node;
    }
    
    public Nodo(){
        this.data = "";
        this.pNext = null;
    }
    
    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public Nodo getpNext() {
        return pNext;
    }

    public void setpNext(Nodo pNext) {
        this.pNext = pNext;
    }
    
    
}
