package proyecto1;

/**
 *
 * @author Emilio Jr
 */
public class Cell {
        private boolean lados[] = {true,true,true,true}; //Los cuatros lados de cada celda (arriba, derecha, abajo, izquierda) --> true para que se dibuje, false para que no.
        private boolean puertas[] = {false,false,false,false}; //Vector para el algoritmo de división recursiva
        private Cell pNext;
        private Cell bottomCell, topCell, rightCell, leftCell; //variables de las celdas adyacentes a una celda.
        private int num; //numero de posición de la celda dentro de la lista.
        private boolean visited; //boolean que permite saber si una celda ya fue visitada.

        
    public Cell(){
       bottomCell = null;
       topCell = null;
       rightCell = null;
       leftCell = null;
       num = 0;
       visited = false;  
    }

    public boolean[] getLados() {
        return lados;
    }

    public void setLados(boolean[] lados) {
        this.lados = lados;
    }

    public boolean[] getPuertas() {
        return puertas;
    }

    public void setPuertas(boolean[] puertas) {
        this.puertas = puertas;
    }
    
      
    public Cell getpNext() {
        return pNext;
    }

    public void setpNext(Cell pNext) {
        this.pNext = pNext;
    }
    
    public Cell getBottomCell() {
        return bottomCell;
    }

    public void setBottomCell(Cell bottomCell) {
        this.bottomCell = bottomCell;
    }

    public Cell getTopCell() {
        return topCell;
    }

    public void setTopCell(Cell upCell) {
        this.topCell = upCell;
    }

    public Cell getRightCell() {
        return rightCell;
    }

    public void setRightCell(Cell rightCell) {
        this.rightCell = rightCell;
    }

    public Cell getLeftCell() {
        return leftCell;
    }

    public void setLeftCell(Cell leftCell) {
        this.leftCell = leftCell;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public boolean isVisited() {
        return visited;
    }

    public void setVisited(boolean visited) {
        this.visited = visited;
    }

        
}

        
